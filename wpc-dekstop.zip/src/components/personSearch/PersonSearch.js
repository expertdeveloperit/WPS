import React, { Component } from 'react';

class PersonSearch extends Component{
	render(){
		return(
			<div>home</div>
		)
	}
}

export default PersonSearch;